@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.advancements.critereon;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;